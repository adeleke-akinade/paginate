<?php

// create a database connection and add a reference to the connection in @var $db
try {
	$db = new PDO('mysql:host=localhost;dbname=database_name', 'username', 'password');
}
catch(PDOexception $e) {
	echo'<p>database connection error</p>';
	print_r($e->getMessage()); // for debugging, remove before submitting to production server.
}
//$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);