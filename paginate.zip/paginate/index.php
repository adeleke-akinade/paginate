<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>PHP pagination tutorial - samwebdesignman.com</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
<div id="main">
	<h1>PHP pagination tutorial - samwebdesignman.com</h1>
	
	<table>
		<thead>
			<tr>
				<td>Name</td>
				<td>Age</td>
				<td>Sign up date and time</td>
			</tr>
		</thead>
		
		<tbody>
	<?php
	require_once'conn.php'; // require database connection
	$query = $db->query('SELECT COUNT(id) FROM paginate'); // count how many rows are in the database table
	$rows = $query->fetchColumn();
	$items_per_page = 10; // set the amount of rows per page
	$last_page = $rows/$items_per_page; // determine the number of the last page

	// check that $_GET['p'] contains a valid number that is not greater than 0 or more than the 
	// number of the last page.
	if(isset($_GET['p']) && ctype_digit($_GET['p']) && $_GET['p'] > 0) {
		$page = $_GET['p'];
	}
	else {
		$page = '1';
	}
	if($page > $last_page) {
		$page = $last_page;
	}
	
	$start = ($page - 1) * $items_per_page; // get the number to be used for the first row in the select query
	
	// create the page controls
	$page_controls = '<p class="page_controls">';
	if($items_per_page > $rows) {
		$page_controls .= '<span>1</span>';
	}
	else {
		if($page > 1) {
			$prev = $page-1;
			$page_controls .= '<a href="?p=' . $prev . '">Prev</a>';
			
			for($i = $page-3; $i < $page; $i++) {
				if($i > 0) {
					$page_controls .= '<a href="?p=' . $i . '">' . $i . '</a>';
				}
			}
		}
		$page_controls .= '<span>' . $page . '</span>';
		if($page < $last_page) {
			for($i = $page+1; $i <= $last_page; $i++) {
				$page_controls .= '<a href="?p=' . $i . '">' . $i . '</a>';
				if($i >= $page+3) {
					break;
				}
			}
			
			$next = $page + 1;
			$page_controls .= '<a href="?p=' . $next . '">Next</a>';
		}
	}
	$page_controls .= '</p>';
	
	$query = $db->prepare("SELECT username, age, signup_date FROM paginate ORDER BY id DESC limit ?, ?");
	$query->bindParam(1, $start, PDO::PARAM_INT);
	$query->bindParam(2, $items_per_page, PDO::PARAM_INT);
	$query->execute();
	foreach($query->fetchAll(PDO::FETCH_ASSOC) as $data) {
		echo '<tr>
			<td>' . $data['username'] . '</td>
			<td>' . $data['age'] . '</td>
			<td>' . $data['signup_date'] . '</td>
		</tr>';
	}
	?>
		</tbody>
	</table>
	
	<?php echo $page_controls; ?>
	
	<p style="text-align: right;">Download the source code - <a href="http://samwebdesignman.com/tutorial/paginate.zip" download>download</a></p>
</div>
</body>
</html>