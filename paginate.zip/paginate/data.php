<?php
require'conn.php';

$db->query('CREATE TABLE IF NOT EXISTS paginate (
	id INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
	username VARCHAR(30) NOT NULL,
	age VARCHAR(2) NOT NULL,
	signup_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)');

$query = $db->query('SELECT COUNT(id) FROM paginate');
$count = $query->fetchColumn();

if($count === '0') {
	$db->query('INSERT INTO paginate (username, age) VALUES ("David", "22"), ("Phil", "35"), ("Stacey", "19"), ("Stefan", "27"), ("Maria", "30"), ("Jonathon", "28"), 
		("Peter", "46"), ("Sarah", "42"), ("Katrina", "25"), ("Bradley", "29"), ("Ben", "31"), ("Marcus", "35"), ("Gemma", "30"), ("Kemi", "17"), ("Patrick", "33"), 
		("Jack", "26"), ("Gregg", "29"), ("Antoine", "22"), ("Martin", "38"), ("Simon", "44"), ("Sophia", "29"), ("Olivia", "31"), ("Isabella", "27"), ("Aiden", "19"), 
		("Liam", "28"), ("Ella", "24"), ("Amelia", "26"), ("Ryan", "23"), ("Layla", "37"), ("Benjamin", "41"), ("Matthew", "24"), ("Owen", "30"), ("Brayden", "17"), 
		("Hannah", "17"), ("Amelia", "56"), ("Connor", "40"), ("James", "29"), ("Dylan", "37"), ("Hailey", "38"), ("Mia", "42"), ("Carter", "20"), ("Lucas", ""), 
		("Timothy", ""), ("Logan", ""), ("Elena", ""), ("David", ""), ("Aria", "24"), ("Levi", "34"), ("Cooper", "46"), ("Chase", "55"), ("Molly", "18"), ("Thomas", "49"),
		("Kyle", "39"), ("Samuel", "21"), ("Evan", "23"), ("Cameron", "34"), ("Gavin", "67"), ("Tyler", "38"), ("Victoria", "29"), ("Maya", "24"), ("Claire", "32"), 
		("Lyla", "29"), ("Evelyn", "47"), ("Lillian", "37"), ("Isaac", "29"), ("Leah", "28"), ("Joseph", "37"), ("Alyssa", "34"), ("Aaron", "45"), ("Blake", "39"),
		("Sean", "21"), ("Alexa", "18"), ("Ruby", "34"), ("Alison", "29"), ("Cole", "35"), ("Jason", "28"), ("Ian", "39"), ("Chris", "31"), ("Sadie", "45"), ("Elise", "36"), 
		("Reese", "29"), ("Asher", "25"), ("Sienna", "33"), ("Kate", "45"), ("Paige", "34"), ("Elise", "29"), ("Brandon", "47"), ("Lincoln", "35"), ("Jasmine", "62"), 
		("Taylor", "47"), ("Miles", "46"), ("Clara", "63"), ("Sasha", "53"), ("Micah", "35"), ("Nathaniel", "35"), ("Eva", "47"), ("Bella", "25"), ("Sydney", "27"), 
		("Parker", "25"), ("Nora", "47"), ("Regan", "27"), ("Tanya", "47"), ("Jesse", "64"), ("Tracy", "23"), ("Austin", "34"), ("Steve", "34"), ("Dominic", "43"), 
		("Ramin", "23"), ("Mick", "56"), ("Talitah", "34"), ("Tasha", "23"), ("Tania", "45"), ("Jenna", "34"), ("Desre", "56"), ("Kirsty", "53"), ("Katherine", "52"), 
		("Willard", "64"), ("William", "26"), ("Frank", "32"), ("Georgina", "23")');
}
?>